package SGD_quadLFT_L3;

import common.TensorQuad;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;

public class SGD_quadLFT_L3_norm_fulltensor{

	/*
	 * SGD方法:SGD是一个隐特征更新的，即在t时刻，Pm,k(t)更新完后，Pm+1,k(t)用到的Pm,k是t时刻的，而不是t-1时刻的
	 *
	 * SGD:
	 * P(t)=P(t-1)-eta*gradient(P(t-1))
	 *
	 * SGD_quadLF:
	 *
	 * object=Math.pow((R-RHat),2)+lambda*Math.pow(A(t-1),2)+lambda*Math.pow(B(t-1),2)+lambda*Math.pow(C(t-1),2)+lambda*Math.pow(D(t-1),2)
	 * RHat=A(t-1)*C(t-1)*C(t-1)*D(t-1) err=R-RHat
	 *
	 * U(t)=U(t-1)-eta*gradient(U(t-1));      gradient(U(t-1)=-err*S(t-1)*T(t-1)+lambda*U(t-1)
	 *     =U(t-1)+eta*err*S(t-1)*T(t-1)-eta*lambda*U(t-1)
	 *
	 * S(t)=S(t-1)-eta*gradient(S(t-1));       gradient(S(t-1)=-err*U(t-1)*T(t-1)+lambda*S(t-1)
	 *     =S(t-1)+eta*err*U(t-1)*T(t-1)-eta*lambda*S(t-1)
	 *
	 * T(t)=T(t-1)-eta*gradient(T(t-1));       gradient(T(t-1)=-err*U(t-1)*S(t-1)+lambda*T(t-1)
	 *     =T(t-1)+eta*err*U(t-1)*S(t-1)-eta*lambda*T(t-1)
	 */

	/*
	 * 
	 * 目标函数构造成一个L1和L2正则的结合，构造成一个L3的距离求解
	 * L3=mu1*L1+mu2*L2
	 * mu2=1-mu1   并且手动调试alpha的值
	 * */
	/**************************************SGD模型的准备工作  start******************************/
	public static int rank; // 张量秩
	public int trainRound = 1000, minRMSERound = 0, minMAERound = 0, delayRound = 50; // 训练轮数和最小轮数
	public double lambda,lambda2,lambdaBias,gamma,eta,mu1,mu2;
	public ArrayList<TensorQuad> data = new ArrayList<TensorQuad>();//存放文件中读取到的数据
	public ArrayList<String> fulleddata = new ArrayList<String>();//存放缺失值预测填充后的完整张量数据
	public ArrayList<TensorQuad> trainData = new ArrayList<TensorQuad>();
	public ArrayList<TensorQuad> testData = new ArrayList<TensorQuad>();
	public ArrayList<String> record = new ArrayList<>();//记录到文本的缓存链表
	public static int testCount = 0;
	public static int maxAId = 0, maxBId = 0, maxCId = 0, maxDId = 0; // 定义4个最大值
	double maxValue=0, minValue=1e10, meanValue=0, stdDev=0;		//rating最大值和最小值
	public double[][] FeatureMatrix_A, FeatureMatrix_B, FeatureMatrix_C,FeatureMatrix_D; // 定义三个特征矩阵
	public double minRMSE = 100, minMAE = 100, lastRMSE=0, lastMAE=0;
	public double everyRoundRMSE[], everyRoundMAE[]; // 定义两个数组，存储每一轮的RMSE，和MAE
	public String dataName= null;

	public static double sigmoid(double x) {
        return 1 / (1 + Math.exp(-x));
    }
	
	
	// 定义4个SGD中间缓存的特征矩阵，存储RMSE和MAE最小时的隐特征，用于张量张量补全
	public double[][] TempFeatureMatrix_A, TempFeatureMatrix_B, TempFeatureMatrix_C,TempFeatureMatrix_D;
	// 为缓存的隐特征矩阵分配空间并初始化
	public void createTempFeatureMatrix() {
		TempFeatureMatrix_A = new double[maxAId +1][rank];  //battery_data id是从0开始的
		TempFeatureMatrix_B = new double[maxBId +1][rank];
		TempFeatureMatrix_C = new double[maxCId +1][rank];
		TempFeatureMatrix_D = new double[maxDId +1][rank];
	}
	public void loadTempFeatureMatrix() {
		for (int max_a_id = 0; max_a_id <= maxAId; max_a_id++) {//battery_data id是从0开始的
			for (int r = 0; r < rank; r++) {
				TempFeatureMatrix_A[max_a_id][r] = 0;
			}
		}
		for (int max_b_id = 0; max_b_id <= maxBId; max_b_id++) {
			for (int r = 0; r < rank; r++) {
				TempFeatureMatrix_B[max_b_id][r] = 0;
			}
		}
		for (int max_c_id = 0; max_c_id <= maxCId; max_c_id++) {
			for (int r = 0; r < rank; r++) {
				TempFeatureMatrix_C[max_c_id][r] = 0;
			}
		}
		for (int max_d_id = 0; max_d_id <= maxDId; max_d_id++) {
			for (int r = 0; r < rank; r++) {
				TempFeatureMatrix_D[max_d_id][r] = 0;
			}
		}
	}
	
	// 定义4个SGD中间缓存的bias向量，存储RMSE和MAE最小时的bias向量，用于张量张量补全
	public double[] TempBiasVector_A, TempBiasVector_B, TempBiasVector_C,TempBiasVector_D;
	// 为缓存的隐特征矩阵分配空间并初始化
	public void createTempBiasVector() {
		TempBiasVector_A = new double[maxAId +1];  //battery_data id是从0开始的
		TempBiasVector_B = new double[maxBId +1];
		TempBiasVector_C = new double[maxCId +1];
		TempBiasVector_D = new double[maxDId +1];
	}
	public void loadTempBiasVector() {
		for (int max_a_id = 0; max_a_id <= maxAId; max_a_id++) {//battery_data id是从0开始的
			TempBiasVector_A[max_a_id] = 0;
		}
		for (int max_b_id = 0; max_b_id <= maxBId; max_b_id++) {
			TempBiasVector_B[max_b_id] = 0;
		}
		for (int max_c_id = 0; max_c_id <= maxCId; max_c_id++) {
			TempBiasVector_C[max_c_id] = 0;
		}
		for (int max_d_id = 0; max_d_id <= maxDId; max_d_id++) {
			TempBiasVector_D[max_d_id] = 0;
		}
	}
	
	public void initializeRatings(String trainFileName, String testFileName, String separator, int nor_way)
			throws NumberFormatException, IOException {
		getTrainData(trainFileName, separator, nor_way);
		getTestData(testFileName, separator, nor_way);
	}

	public void getMaxMinValue(String fileName, String separator) throws IOException{
		File file = new File(fileName);
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line = null;
		double sumValue=0;
		int data_length=0;
		while ((line = br.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, separator);
			String t_AId = null;
			if (st.hasMoreTokens()) {
				t_AId = st.nextToken();
			}
			
			String t_BId = null;
			if (st.hasMoreTokens()) {
				t_BId = st.nextToken();
			}
			String t_CId = null;
			if (st.hasMoreTokens()) {
				t_CId = st.nextToken();
			}
			String t_DId = null;
			if (st.hasMoreTokens()) {
				t_DId = st.nextToken();
			}
			String t_rating = null;
			if (st.hasMoreTokens()) {
				t_rating = st.nextToken();
			}
			TensorQuad T_quad = new TensorQuad();
			T_quad.AId = Integer.valueOf(t_AId);
			T_quad.BId = Integer.valueOf(t_BId);
			T_quad.CId = Integer.valueOf(t_CId);
			T_quad.DId = Integer.valueOf(t_DId);
			T_quad.rating = Double.valueOf(t_rating);
			data.add(T_quad);

			maxAId = (maxAId > T_quad.AId) ? maxAId : T_quad.AId;
			maxBId = (maxBId > T_quad.BId) ? maxBId : T_quad.BId;
			maxCId = (maxCId > T_quad.CId) ? maxCId : T_quad.CId;
			maxDId = (maxDId > T_quad.DId) ? maxDId : T_quad.DId;
			
			//读取所有值的和，求均值
			sumValue=sumValue+T_quad.rating;
			data_length=data_length+1;
			
//			System.out.println(line);
		}
		br.close();
		
		System.out.println("sumValue"+sumValue);
		System.out.println("data_length"+data_length);
		
		//计算得到所有数据的均值
		meanValue=sumValue/data_length;

		double sum=0; //计算每个数据和平均值的差的平方和
		for (TensorQuad t_quad : data) {//遍历读取文件中的条目
			//读取最大值
			if(maxValue<t_quad.rating){
				maxValue=t_quad.rating;
			}
			//读取最小值
			if(minValue>t_quad.rating){
				minValue=t_quad.rating;
			}
			//计算每个数据和平均值的差的平方和
			sum=sum+Math.pow(t_quad.rating-meanValue,2);
		}
		//求得标准差
		stdDev = Math.sqrt(sum / data_length);
		
		System.out.println(maxValue+"::"+minValue+"::"+meanValue+"::"+stdDev);
		System.out.println(maxAId+"×"+maxBId+"×"+maxCId+"×"+maxDId);
	}


	// 获取训练集元素
	public void getTrainData(String fileName, String separator, int nor_way) throws IOException {
		this.dataName = fileName;
		File file = new File(fileName);
		BufferedReader br = new BufferedReader(new FileReader(file));

		String line = null;
		while ((line = br.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, separator);
			String t_AId = null;
			if (st.hasMoreTokens()) {
				t_AId = st.nextToken();
			}
			String t_BId = null;
			if (st.hasMoreTokens()) {
				t_BId = st.nextToken();
			}
			String t_CId = null;
			if (st.hasMoreTokens()) {
				t_CId = st.nextToken();
			}
			String t_DId = null;
			if (st.hasMoreTokens()) {
				t_DId = st.nextToken();
			}
			String t_rating = null;
			if (st.hasMoreTokens()) {
				t_rating = st.nextToken();
			}
			TensorQuad T_quad = new TensorQuad();
			T_quad.AId = Integer.valueOf(t_AId);
			T_quad.BId = Integer.valueOf(t_BId);
			T_quad.CId = Integer.valueOf(t_CId);
			T_quad.DId = Integer.valueOf(t_DId);
			T_quad.rating = Double.valueOf(t_rating);

			//数据归一化
			Double nor_value=0.0;
			//归一化方法1：
			if(nor_way==1) {
				if (T_quad.rating>0) {
					nor_value = T_quad.rating / Math.abs(maxValue);//归一化数据，保持非负同比例归一化
				}
				else if (T_quad.rating<=0){
					nor_value = T_quad.rating / Math.abs(maxValue);
				}
			}
			else if(nor_way==2) {
				//归一化方法2：
				nor_value=(T_quad.rating-minValue)/(maxValue-minValue);
			}
			else if(nor_way==3) {
				//归一化方法3：标准归一化
				nor_value=(T_quad.rating-meanValue)/stdDev;
			}
			else if(nor_way==4) {
				//归一化方法4：sigmod归一化
				nor_value=sigmoid((T_quad.rating-meanValue)/stdDev);
			}
			
			T_quad.rating=nor_value;

			trainData.add(T_quad);

			maxAId = (maxAId > T_quad.AId) ? maxAId : T_quad.AId;
			maxBId = (maxBId > T_quad.BId) ? maxBId : T_quad.BId;
			maxCId = (maxCId > T_quad.CId) ? maxCId : T_quad.CId;
			maxDId = (maxDId > T_quad.DId) ? maxDId : T_quad.DId;

		}
		br.close();

		double train_maxValue=0.0;
		double train_minValue=0.0;
		//归一化之后得到的最大最小值
		for (TensorQuad t_quad : trainData) {//遍历读取文件中的条目
			//读取最大值
			if(train_maxValue<t_quad.rating){
				train_maxValue=t_quad.rating;
			}
			//读取最小值
			if(train_minValue>t_quad.rating){
				train_minValue=t_quad.rating;
			}
		}
		System.out.println("train_maxValue:"+train_maxValue+",train_minValue:"+train_minValue);
	}

	// 获取测试集元素
	public void getTestData(String fileName, String separator, int nor_way) throws IOException {
		File file = new File(fileName);
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line = null;
		while ((line = br.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line, separator);
			String t_AId = null;
			if (st.hasMoreTokens()) {
				t_AId = st.nextToken();
			}
			String t_BId = null;
			if (st.hasMoreTokens()) {
				t_BId = st.nextToken();
			}
			String t_CId = null;
			if (st.hasMoreTokens()) {
				t_CId = st.nextToken();
			}
			String t_DId = null;
			if (st.hasMoreTokens()) {
				t_DId = st.nextToken();
			}
			String t_rating = null;
			if (st.hasMoreTokens()) {
				t_rating = st.nextToken();
			}
			TensorQuad T_quad = new TensorQuad();
			T_quad.AId = Integer.valueOf(t_AId);
			T_quad.BId = Integer.valueOf(t_BId);
			T_quad.CId = Integer.valueOf(t_CId);
			T_quad.DId = Integer.valueOf(t_DId);
			T_quad.rating = Double.valueOf(t_rating);

			//数据归一化
			Double nor_value=0.0;
			
			//归一化方法1：
			if(nor_way==1) {
				if (T_quad.rating>0) {
					nor_value = T_quad.rating / Math.abs(maxValue);//归一化数据，保持非负同比例归一化
				}
				else if (T_quad.rating<=0){
					nor_value = T_quad.rating / Math.abs(maxValue);
				}
			}
			else if(nor_way==2) {
				//归一化方法2：
				nor_value=(T_quad.rating-minValue)/(maxValue-minValue);
			}
			else if(nor_way==3) {
				//归一化方法3：标准归一化
				nor_value=(T_quad.rating-meanValue)/stdDev;
			}
			else if(nor_way==4) {
				//归一化方法4：sigmod归一化
				nor_value=sigmoid((T_quad.rating-meanValue)/stdDev);
			}
			
			T_quad.rating=nor_value;

			testData.add(T_quad);
			maxAId = (maxAId > T_quad.AId) ? maxAId : T_quad.AId;
			maxBId = (maxBId > T_quad.BId) ? maxBId : T_quad.BId;
			maxCId = (maxCId > T_quad.CId) ? maxCId : T_quad.CId;
			maxDId = (maxDId > T_quad.DId) ? maxDId : T_quad.DId;
			testCount++;
		}
		br.close();

		double test_maxValue=0.0;
		double test_minValue=0.0;
		//归一化之后得到的最大最小值
		for (TensorQuad t_quad : testData) {//遍历读取文件中的条目
			//读取最大值
			if(test_maxValue<t_quad.rating){
				test_maxValue=t_quad.rating;
			}
			//读取最小值
			if(test_minValue>t_quad.rating){
				test_minValue=t_quad.rating;
			}
		}
		System.out.println("test_maxValue:"+test_maxValue+",test_minValue:"+test_minValue);
	}


	public int scale = 1000;
	public double initscale = 0.08;   //设置为0.0004时，RMSE和MAE会往上升
	public void initiRandomcArrays() {
		FeatureMatrix_A = new double[maxAId + 1][rank];
		FeatureMatrix_B = new double[maxBId + 1][rank];
		FeatureMatrix_C = new double[maxCId + 1][rank];
		FeatureMatrix_D = new double[maxDId + 1][rank];
		// 若T的值为0，那么随机初始化参数值
		Random random = new Random();
		for (int a_id = 0; a_id <= maxAId; a_id++) {  //由于读取数据的id从0开始，因此id也从0开始
			for (int r = 0; r < rank; r++) {
				FeatureMatrix_A[a_id][r] = initscale * random.nextInt(scale) / scale; // 0.005;//
				// 随机值初始化特征矩阵initscale*random.nextInt(scale)/scale
			}
		}
		for (int b_id = 0; b_id <= maxBId; b_id++) {
			for (int r = 0; r < rank; r++) {
				FeatureMatrix_B[b_id][r] = initscale * random.nextInt(scale) / scale; // 0.005;//
				// 随机值初始化特征矩阵
			}
		}
		for (int c_id = 0; c_id <= maxCId; c_id++) {
			for (int r = 0; r < rank; r++) {
				FeatureMatrix_C[c_id][r] = initscale * random.nextInt(scale) / scale; // 0.005;//随机值初始化特征矩阵
			}
		}
		for (int d_id = 0; d_id <= maxDId; d_id++) {
			for (int r = 0; r < rank; r++) {
				FeatureMatrix_D[d_id][r] = initscale * random.nextInt(scale) / scale; // 0.005;//随机值初始化特征矩阵
			}
		}
	}

	public void resertMin() {
		minRMSE = 100;
		minMAE = 100;
		minRMSERound = 0;
		minMAERound = 0;
	}

	public double getPredection(int a_Id, int b_Id, int c_Id, int d_Id) {
		double p_ratingHat = 0;
		for (int r = 0; r < rank; r++) {
			p_ratingHat += FeatureMatrix_A[a_Id][r] * FeatureMatrix_B[b_Id][r] * FeatureMatrix_C[c_Id][r]* FeatureMatrix_D[d_Id][r];
		}
		return p_ratingHat;
	}
	
	public double getPredection_fulledtensor(int a_Id, int b_Id, int c_Id, int d_Id) {
		double p_ratingHat = 0;
		for (int r = 0; r < rank; r++) {
			p_ratingHat += TempFeatureMatrix_A[a_Id][r] * TempFeatureMatrix_B[b_Id][r] * TempFeatureMatrix_C[c_Id][r]* TempFeatureMatrix_D[d_Id][r];
		}
		p_ratingHat=p_ratingHat+TempBiasVector_A[a_Id]+TempBiasVector_B[b_Id]+TempBiasVector_C[c_Id]+TempBiasVector_D[d_Id];
		return p_ratingHat;
	}

	public void recordTxts(String recordTxt){
		String str = dataName.replace("D:\\dataset\\toyota\\不同填充方法填充后的全张量数据\\", "").replace("trainR.txt", "");
		String fileName = str + recordTxt+ ".txt";
		File file = null;
		BufferedWriter bw = null;
		try {
			file = new File("./data/"+ fileName);
			bw = new BufferedWriter(new FileWriter(file));
			for (String record:record) {
				bw.write(record+"\n");
				bw.flush();
			}
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	//定义一个四维数组存储battery_quadtensor
	public double[][][][] battery_quadtensor;
	public void fulltensor(String parastr, int nor_way){
		battery_quadtensor=new double[maxAId+1][maxBId+1][maxCId+1][maxDId+1];
		for (int a_id = 0; a_id <= maxAId; a_id++) {
			for (int b_id = 0; b_id <= maxBId; b_id++) {
				for (int c_id = 0; c_id <= maxCId; c_id++) {
					for (int d_id = 0; d_id <= maxDId; d_id++) {
						battery_quadtensor[a_id][b_id][c_id][d_id]=3.1415926; //初始化battery_quadtensor的值
					}
				}
			}
		}
		//将已知值赋值给张量battery_quadtensor
		int known_num=0;
		for (TensorQuad known_tuple : data) {
			battery_quadtensor[known_tuple.AId][known_tuple.BId][known_tuple.CId][known_tuple.DId]=known_tuple.rating;
			known_num+=1;
		}
		System.out.println("known_num:"+known_num);
		
		//填充预测值
		int init_num=0;
		double reNor_maxvalue=0.0;  //恢复归一化之后的值
		double reNor_minvalue=1e10;
		
		int unknown_num=0;
		for (int a_id = 0; a_id <= maxAId; a_id++) {
			for (int b_id = 0; b_id <= maxBId; b_id++) {
				for (int c_id = 0; c_id <= maxCId; c_id++) {
					for (int d_id = 0; d_id <= maxDId; d_id++) {
						String fulledtensor_term=null;
						//读取未知元素
						if(battery_quadtensor[a_id][b_id][c_id][d_id]==3.1415926){
							//通过隐特征矩阵运算并还原归一化
							if(nor_way==1) {
								//归一化方法1还原归一化：
								battery_quadtensor[a_id][b_id][c_id][d_id]=getPredection_fulledtensor(a_id, b_id, c_id, d_id)*Math.abs(maxValue);//将隐特征预测过的值进行返归一化
							}
							else if (nor_way==2) {
							//归一化方法2还原归一化：
								battery_quadtensor[a_id][b_id][c_id][d_id]=getPredection_fulledtensor(a_id, b_id, c_id, d_id)*(maxValue-minValue)+minValue;
							}
							else if(nor_way==3) {
							//归一化方法3还原归一化
								battery_quadtensor[a_id][b_id][c_id][d_id]=getPredection_fulledtensor(a_id, b_id, c_id, d_id)*stdDev+meanValue;
							}
							else if(nor_way==4) {
							//归一化方法4还原归一化
								battery_quadtensor[a_id][b_id][c_id][d_id]=(-Math.log((1 / getPredection_fulledtensor(a_id, b_id, c_id, d_id)) - 1))*stdDev+meanValue;
								unknown_num+=1;
							}
						}
						//统计未预测到的未知元素
						if(battery_quadtensor[a_id][b_id][c_id][d_id]==3.1415926){
							init_num=+1;
							System.out.println("异常值："+a_id+" "+b_id+" "+c_id+" "+d_id);
						}
						double reNor_value=battery_quadtensor[a_id][b_id][c_id][d_id];
						//读取最大值
						if(reNor_maxvalue<reNor_value){
							reNor_maxvalue=reNor_value;
						}
						//读取最小值
						if(reNor_minvalue>reNor_value){
							reNor_minvalue=reNor_value;
						}
						fulledtensor_term=a_id+" "+b_id+" "+c_id+" "+d_id+" "+reNor_value;
						fulleddata.add(fulledtensor_term);
					}
				}
			}
		}
		System.out.println("unknown_num:"+unknown_num);
		System.out.println("reNor_maxvalue:"+reNor_maxvalue);
		System.out.println("reNor_minvalue:"+reNor_minvalue);
		//将填充后的全张量数据输出：
		String str = dataName.replace("D:\\dataset\\toyota\\不同填充方法填充后的全张量数据\\", "").replace("trainR.txt", "");
		String fileName = str + "fulledbySGDL3_"+parastr+"_norway"+nor_way+".txt";
		File file = null;
		BufferedWriter bw = null;
		try {
			file = new File("D:\\dataset\\toyota\\不同填充方法填充后的全张量数据\\"+ fileName);
			bw = new BufferedWriter(new FileWriter(file));
			for (String record:fulleddata) {
				bw.write(record+"\n");
				bw.flush();
			}
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**************************************SGD模型的准备工作  end******************************/


	/*****************************************训练模型  start*********************************/
	//开始训练
	public void train() throws IOException {

		for (int round = 1; round <= trainRound; round++) {

			// 记录训练开始时间
			long startTime = System.currentTimeMillis();

			// 训练隐特征矩阵
			for (TensorQuad t_tuple : trainData) {//一个一个训练元素更新

				// rHat=P(t-1)*Q(t-1)
				t_tuple.ratingHat = this.getPredection(t_tuple.AId, t_tuple.BId, t_tuple.CId, t_tuple.DId);
				double err = t_tuple.rating - t_tuple.ratingHat;

				
				if(err>=0) {
					for (int r = 0; r < rank; r++) {
							// 暂时缓存隐特征的值
						FeatureMatrix_A[t_tuple.AId][r] = FeatureMatrix_A[t_tuple.AId][r]
								+ mu1*eta*FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_C[t_tuple.CId][r]* FeatureMatrix_D[t_tuple.DId][r]
								+ mu2*eta * err * FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_C[t_tuple.CId][r]* FeatureMatrix_D[t_tuple.DId][r]
								- eta * lambda * FeatureMatrix_A[t_tuple.AId][r]
								- eta * lambda2;// 正则化项
						
						FeatureMatrix_B[t_tuple.BId][r] = FeatureMatrix_B[t_tuple.BId][r]
								+ mu1*eta*FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_C[t_tuple.CId][r]* FeatureMatrix_D[t_tuple.DId][r]
								+ mu2* eta * err * FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_C[t_tuple.CId][r]* FeatureMatrix_D[t_tuple.DId][r]
								- eta * lambda * FeatureMatrix_B[t_tuple.BId][r]- eta * lambda2;// 正则化项

						FeatureMatrix_C[t_tuple.CId][r] = FeatureMatrix_C[t_tuple.CId][r]
								+ mu1*eta*FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_D[t_tuple.DId][r]
								+ mu2* eta * err * FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_D[t_tuple.DId][r]
								- eta * lambda * FeatureMatrix_C[t_tuple.CId][r]- eta * lambda2;// 正则化项

						FeatureMatrix_D[t_tuple.DId][r] = FeatureMatrix_D[t_tuple.DId][r]
								+ mu1*eta*FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_C[t_tuple.CId][r]
								+ mu2* eta * err * FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_C[t_tuple.CId][r]
								- eta * lambda * FeatureMatrix_D[t_tuple.DId][r]- eta * lambda2;// 正则化项
					}
				}
				else if(err<0) {
					for (int r = 0; r < rank; r++) {
						FeatureMatrix_A[t_tuple.AId][r] = FeatureMatrix_A[t_tuple.AId][r]
								- mu1*eta*FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_C[t_tuple.CId][r]* FeatureMatrix_D[t_tuple.DId][r]
								+ mu2*eta * err * FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_C[t_tuple.CId][r]* FeatureMatrix_D[t_tuple.DId][r]
								- eta * lambda * FeatureMatrix_A[t_tuple.AId][r]- eta * lambda2;// 正则化项
						
						FeatureMatrix_B[t_tuple.BId][r] = FeatureMatrix_B[t_tuple.BId][r]
								- mu1*eta*FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_C[t_tuple.CId][r]* FeatureMatrix_D[t_tuple.DId][r]
								+ mu2* eta * err * FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_C[t_tuple.CId][r]* FeatureMatrix_D[t_tuple.DId][r]
								- eta * lambda * FeatureMatrix_B[t_tuple.BId][r]- eta * lambda2;// 正则化项

						FeatureMatrix_C[t_tuple.CId][r] = FeatureMatrix_C[t_tuple.CId][r]
								- mu1*eta*FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_D[t_tuple.DId][r]
								+ mu2* eta * err * FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_D[t_tuple.DId][r]
								- eta * lambda * FeatureMatrix_C[t_tuple.CId][r]- eta * lambda2;// 正则化项

						FeatureMatrix_D[t_tuple.DId][r] = FeatureMatrix_D[t_tuple.DId][r]
								- mu1*eta*FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_C[t_tuple.CId][r]
								+ mu2* eta * err * FeatureMatrix_A[t_tuple.AId][r] * FeatureMatrix_B[t_tuple.BId][r]* FeatureMatrix_C[t_tuple.CId][r]
								- eta * lambda * FeatureMatrix_D[t_tuple.DId][r]- eta * lambda2;// 正则化项
					}
				}

			}

			// 训练结束时间
			long endTime = System.currentTimeMillis();
			long iterationTime = endTime - startTime;

			double curErrRMSE;
			double curErrMAE;
			double square = 0, absCount = 0;
			for (TensorQuad test_tuple : testData) {
				// 获得元素的预测值
				test_tuple.ratingHat = this.getPredection(test_tuple.AId, test_tuple.BId, test_tuple.CId, test_tuple.DId);
				square += Math.pow(test_tuple.rating - test_tuple.ratingHat, 2);
				absCount += Math.abs(test_tuple.rating - test_tuple.ratingHat);
			}
			curErrRMSE = Math.sqrt(square / testCount);
			curErrMAE = absCount / testCount;

			double errRMSE = Math.abs(lastRMSE - curErrRMSE);
			double errMAE = Math.abs(lastMAE - curErrMAE);

			// double curErrRMSE;
			// double curErrMAE;
			//
			// curErrRMSE = this.testCurrentRMSE();
			// curErrMAE = this.testCurrentMAE();

			if ((minRMSE > curErrRMSE) ) {//&& (errRMSE > Math.pow(10, -12))
				minRMSE = curErrRMSE;
				this.minRMSERound = round;	
				
				//将RMSE最小时的隐特征矩阵存储下来
				for (int r = 0; r < rank; r++) {
					for (int a_id = 0; a_id <= maxAId; a_id++) {
						TempFeatureMatrix_A[a_id][r]=FeatureMatrix_A[a_id][r];
					}
					for (int b_id = 0; b_id <= maxBId; b_id++) {
						TempFeatureMatrix_B[b_id][r]=FeatureMatrix_B[b_id][r];
					}
					for (int c_id = 0; c_id <= maxCId; c_id++) {
						TempFeatureMatrix_C[c_id][r]=FeatureMatrix_C[c_id][r];
					}
					for (int d_id = 0; d_id <= maxDId; d_id++) {
						TempFeatureMatrix_D[d_id][r]=FeatureMatrix_D[d_id][r];
					}
				}
				
			}
			if ((minMAE > curErrMAE) ) {//&& (errMAE > Math.pow(10, -12))
				minMAE = curErrMAE;
				this.minMAERound = round;
				
				//将MAE最小时的隐特征矩阵存储下来
//				for (int r = 0; r < rank; r++) {
//					for (int a_id = 0; a_id <= maxAId; a_id++) {
//						TempFeatureMatrix_A[a_id][r]=FeatureMatrix_A[a_id][r];
//					}
//					for (int b_id = 0; b_id <= maxBId; b_id++) {
//						TempFeatureMatrix_B[b_id][r]=FeatureMatrix_B[b_id][r];
//					}
//					for (int c_id = 0; c_id <= maxCId; c_id++) {
//						TempFeatureMatrix_C[c_id][r]=FeatureMatrix_C[c_id][r];
//					}
//					for (int d_id = 0; d_id <= maxDId; d_id++) {
//						TempFeatureMatrix_D[d_id][r]=FeatureMatrix_D[d_id][r];
//					}
//				}
				
			} else if (((round - minRMSERound > delayRound) && (round - minMAERound > delayRound))
					|| ((errRMSE < Math.pow(10, -5)) && (errMAE < Math.pow(10, -5)))) {
				break;
			}

			lastRMSE = curErrRMSE;
			lastMAE = curErrMAE;

			String record1 = round + "::" + curErrRMSE + "::" + curErrMAE;
			record.add(record1);
//			System.out.println(iterationTime + "--" + round + "::" + curErrRMSE + "::" + curErrMAE);
//			System.out.printf("%.23f",  curErrRMSE);
//			System.out.println("");

		}

		String record2 = minRMSERound + "::" + minRMSE + "::" + minMAERound + "::" + minMAE;
		record.add(record2);
		System.out.println(minRMSERound + "::" + minRMSE + "::" + minMAERound + "::" + minMAE);

	}
	/*****************************************训练模型  end*********************************/


	public static void main(String[] args) throws NumberFormatException, IOException {

		SGD_quadLFT_L3_norm_fulltensor index = new SGD_quadLFT_L3_norm_fulltensor();
		index.rank=40;

		//归一化方式
		//way 1: nor_value=value/abs(maxValue)
		//way 2: nor_value=(value-minValue)/(maxValue-minValue);
		//way 3: nor_value=(value-meanValue)/stdDev;
		//way 4: sigmoid((T_quad.rating-meanValue)/stdDev);
		int nor_way=2; 
		System.out.println("nor_way="+nor_way);

		//读取数据的最大最小值
		index.getMaxMinValue("D:\\dataset\\toyota\\不同缺失率下的张量结构数据\\toyota_4Dtensor_124_200_100_7_data_s0.99.txt"," ");

		// 读取训练集、测试集文件
		index.initializeRatings("D:\\dataset\\toyota\\不同缺失率下的张量结构数据\\toyota_4Dtensor_124_200_100_7_data_s0.99_p80_trainR.txt",
				"D:\\dataset\\toyota\\不同缺失率下的张量结构数据\\toyota_4Dtensor_124_200_100_7_data_s0.99_p80_testR.txt", " ", nor_way);
		
		// 为辅助矩阵开辟空间
		index.createTempFeatureMatrix();
		index.createTempBiasVector();

		// 参数设置
//		index.mu1=0;
//		index.mu2=1-index.mu1;
		double[] mu1List = {0.1};//{0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9};
		double[] lambdaList = {0.0000000001}; //{ 0.0000000001}; // 矩阵正则化参数
		double[] lambda2List ={0};
		double[] etaList = { 0.05};
		String str;
		for (int m=0; m < mu1List.length; m++) {
			index.mu1=mu1List[m];
			index.mu2=1-index.mu1;
		for (int l = 0; l < lambdaList.length; l++) {
			index.lambda = lambdaList[l];
			index.lambda2 = lambda2List[0];
			for (int e = 0; e < etaList.length; e++) {
				index.eta = etaList[e];
				str = "initscale:"+index.initscale+" rank:" + index.rank+"lambda" + index.lambda + "::eta" + index.eta+" mu1:"+index.mu1+" mu2:"+index.mu2;
				System.out.println(str);
				index.record.add(str);

				index.initiRandomcArrays();
				index.loadTempFeatureMatrix();
				index.loadTempBiasVector();

				index.resertMin();// 每次训练之前将重置RMSE,MAE,RMSEround,MAEround
				index.train();
				//输出补全后的张量
//				String pra="s"+index.initscale+"_r"+index.rank+"_l" + index.lambda + "_e" + index.eta+"_m1"+index.mu1+"_m2"+index.mu2;
//				index.fulltensor(pra, nor_way);
			}
		}
		}
		String parameter ="s"+index.initscale+"r"+index.rank+"l" + lambdaList[0]+"_"+lambdaList[lambdaList.length-1]+"e" + index.eta+  "_";

		String recordTxtTitle = "_SGD_quadLFT_L3" + parameter;

		index.recordTxts(recordTxtTitle);// 将record记录到文件中

	}

}
