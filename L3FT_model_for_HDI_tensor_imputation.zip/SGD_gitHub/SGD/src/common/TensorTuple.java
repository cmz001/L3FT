package common;

public class TensorTuple {
	public int UId;
	public int SId;
	public int TId;
	public double rating=0;
	public double ratingHat=0;
}
