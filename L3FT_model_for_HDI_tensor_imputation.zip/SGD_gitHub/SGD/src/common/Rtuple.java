package common;

public class Rtuple {
	public int UId;
	public int IId;
	public double rating;
	public double ratingHat=0;
}
