package common;

public class TensorQuad {
	public int AId;
	public int BId;
	public int CId;
	public int DId;
	public double rating=0;
	public double ratingHat=0;
}
